import { Component } from '@angular/core';
import {SearchForm} from './search-form'
import { SearchService } from "../search.service";
import { FormGroup, FormControl } from '@angular/forms';

@Component ({
    selector:'app-search-form',
    templateUrl: './search-form.component.html',
    styleUrls:['./search-form.component.css']
})


export class SearchFromComponent{
  typeZip: string
  autoCom: any[]
  zip: string;
  gotZip: boolean = false
  useCurLoc: boolean = true;
  form = SearchForm;
  category = "All Categories";
  constructor(private searchService: SearchService) {}


  localClick(x) {
    if(x==1){
      this.useCurLoc=false;
    } else {
      this.useCurLoc=true;
    }
    }

  cateType = ["All Categories", "Art", "Baby", "Books",
"Clothing, Shoes & Accessories", "Computers/Tablets & Networking",
"Health & Beauty", "Music", "Video Games & Consoles"];

  conditions = [{
   name: 'New' , selected : false,
  },
  {
   name: 'Used'  , selected : false,
  },
  {
   name: 'Unspecified'  , selected : false,
  }
]
shippings= [{
  name: 'Local Pickup' , selected : false,
 },
 {
  name: 'Free Shipping'  , selected : false,
 }
]

getZip() {
  this.searchService.getGeolocation().subscribe(data => {
    this.zip = data["zip"]
    this.form.zip = this.zip;
    this.gotZip = true;
  })
}

ngOnInit() {
  this.getZip();

}

}
