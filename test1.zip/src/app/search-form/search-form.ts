export const SearchForm = {
  keyword: '',
  category: 'All Catogories',
  condition: '',
  shipping: '',
  distance: '',
  zip: ''
}
